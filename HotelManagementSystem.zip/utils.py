import subprocess
from PyQt5.QtWidgets import QApplication

def logout(current_window):
    """تسجيل الخروج وإعادة تشغيل التطبيق."""
    # إغلاق النافذة الحالية
    current_window.close()

    # إعادة تشغيل الملف الرئيسي (main.py)
    subprocess.Popen(["python", "main.py"])

    # إنهاء العملية الحالية
    app = QApplication.instance()
    app.quit()