


    def refresh_table(self, table, query, params=None):
        """
        Refresh the QTableWidget with the latest data from the database.
        
        :param table: The QTableWidget to refresh.
        :param query: The SQL query to fetch the latest data.
        :param params: Optional parameters for the query.
        """
        try:
            # Fetch the latest data from the database
            if params:
                data = self.db.fetch_data(query, params)
            else:
                data = self.db.fetch_data(query)

            # Clear existing rows in the table
            table.setRowCount(0)

            # Populate the table with the new data
            for row, record in enumerate(data):
                table.insertRow(row)
                for col, value in enumerate(record):
                    table.setItem(row, col, QTableWidgetItem(str(value)))

        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred while refreshing the table: {str(e)}")


    def manage_guests(self):
        query = """
            SELECT g.guest_id, g.f_name, g.l_name, g.password, ge.email, gp.phone
            FROM Guest g
            INNER JOIN GuestEmail ge ON g.guest_id = ge.guest_id
            INNER JOIN GuestPhone gp ON g.guest_id = gp.guest_id
        """
        guests_data = self.db.fetch_data(query)
        if not guests_data:
            QMessageBox.information(self, "Info", "No guests found.")
            return

        self.guest_window = QWidget()
        self.guest_window.setWindowTitle("Manage Guests")
        self.guest_window.setGeometry(200, 200, 800, 400)
        layout = QVBoxLayout()

        table = QTableWidget()
        table.setColumnCount(6)
        table.setHorizontalHeaderLabels(["ID", "First Name", "Last Name", "Password", "Email", "Phone"])
        self.refresh_table(table, query)  # Use refresh_table to populate the table
        layout.addWidget(table)

        edit_button = QPushButton("Edit Guest")
        self.style_button(edit_button, "#28a745")
        edit_button.clicked.connect(lambda: self.edit_guest(table))
        layout.addWidget(edit_button)

        add_button = QPushButton("Add New Guest")
        self.style_button(add_button, "#007bff")
        add_button.clicked.connect(self.add_new_guest)
        layout.addWidget(add_button)

        delete_button = QPushButton("Delete Guest")
        self.style_button(delete_button, "#dc3545")
        delete_button.clicked.connect(lambda: self.delete_guest(table))
        layout.addWidget(delete_button)

        self.guest_window.setLayout(layout)
        self.guest_window.show()

    def edit_guest(self, table):
        selected_row = table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Error", "Please select a guest to edit.")
            return

        guest_id = table.item(selected_row, 0).text()
        current_f_name = table.item(selected_row, 1).text()
        current_l_name = table.item(selected_row, 2).text()
        current_password = table.item(selected_row, 3).text()
        current_email = table.item(selected_row, 4).text()
        current_phone = table.item(selected_row, 5).text()

        f_name, ok = QInputDialog.getText(self, "Edit Guest", "Enter new first name:", text=current_f_name)
        if not ok or not f_name:
            return

        l_name, ok = QInputDialog.getText(self, "Edit Guest", "Enter new last name:", text=current_l_name)
        if not ok or not l_name:
            return

        password, ok = QInputDialog.getText(self, "Edit Guest", "Enter new password (leave blank to keep current):", QLineEdit.Password)
        if not ok:
            return

        email, ok = QInputDialog.getText(self, "Edit Guest", "Enter new email:", text=current_email)
        if not ok or not email:
            return

        phone, ok = QInputDialog.getText(self, "Edit Guest", "Enter new phone number:", text=current_phone)
        if not ok or not phone:
            return

        update_guest_query = "UPDATE Guest SET f_name = ?, l_name = ?, password = ? WHERE guest_id = ?"
        update_email_query = "UPDATE GuestEmail SET email = ? WHERE guest_id = ?"
        update_phone_query = "UPDATE GuestPhone SET phone = ? WHERE guest_id = ?"

        success_guest = self.db.execute_query(update_guest_query, (f_name, l_name, password, guest_id))
        success_email = self.db.execute_query(update_email_query, (email, guest_id))
        success_phone = self.db.execute_query(update_phone_query, (phone, guest_id))

        if success_guest and success_email and success_phone:
            QMessageBox.information(self, "Success", "Guest data updated successfully.")
            # Refresh the table to reflect the changes
            query = """
                SELECT g.guest_id, g.f_name, g.l_name, g.password, ge.email, gp.phone
                FROM Guest g
                INNER JOIN GuestEmail ge ON g.guest_id = ge.guest_id
                INNER JOIN GuestPhone gp ON g.guest_id = gp.guest_id
            """
            self.refresh_table(table, query)
        else:
            QMessageBox.warning(self, "Error", "Failed to update guest data.")


    def add_new_guest(self):
        """Add a new guest."""
        try:
            # Prompt the user to enter guest details
            f_name, ok = QInputDialog.getText(self, "Add Guest", "Enter first name:")
            if not ok or not f_name:
                return

            l_name, ok = QInputDialog.getText(self, "Add Guest", "Enter last name:")
            if not ok or not l_name:
                return

            password, ok = QInputDialog.getText(self, "Add Guest", "Enter password:", QLineEdit.Password)
            if not ok or not password:
                return

            email, ok = QInputDialog.getText(self, "Add Guest", "Enter email:")
            if not ok or not email:
                return

            phone, ok = QInputDialog.getText(self, "Add Guest", "Enter phone number:")
            if not ok or not phone:
                return

            # Generate a new guest ID
            max_guest_id_query = "SELECT MAX(guest_id) FROM Guest"
            max_guest_id_result = self.db.fetch_data(max_guest_id_query)
            guest_id = 1 if max_guest_id_result[0][0] is None else max_guest_id_result[0][0] + 1

            # Insert the new guest into the database
            insert_guest_query = "INSERT INTO Guest (guest_id, f_name, l_name, password) VALUES (?, ?, ?, ?)"
            success_guest = self.db.execute_query(insert_guest_query, (guest_id, f_name, l_name, password))

            if not success_guest:
                QMessageBox.warning(self, "Error", "Failed to add guest.")
                return

            insert_email_query = "INSERT INTO GuestEmail (guest_id, email) VALUES (?, ?)"
            email_success = self.db.execute_query(insert_email_query, (guest_id, email))

            if not email_success:
                QMessageBox.warning(self, "Error", "Failed to add email.")
                return

            insert_phone_query = "INSERT INTO GuestPhone (guest_id, phone) VALUES (?, ?)"
            phone_success = self.db.execute_query(insert_phone_query, (guest_id, phone))

            if not phone_success:
                QMessageBox.warning(self, "Error", "Failed to add phone number.")
                return

            QMessageBox.information(self, "Success", "Guest added successfully.")
            # Refresh the table to show the new guest
            self.refresh_guest_table(self.table)

        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")

    def delete_guest(self, table):
        """حذف ضيف."""
        # الحصول على الصف المحدد
        selected_row = table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Error", "Please select a guest to delete.")
            return

        # استخراج معرف الضيف من الصف المحدد
        guest_id = table.item(selected_row, 0).text()

        # تأكيد الحذف
        confirm = QMessageBox.question(
            self,
            "Confirm Deletion",
            f"Are you sure you want to delete guest with ID {guest_id}?",
            QMessageBox.Yes | QMessageBox.No
        )

        if confirm == QMessageBox.Yes:
            try:
                # حذف السجل من جدول Guest
                delete_guest_query = "DELETE FROM Guest WHERE guest_id = ?"
                success_guest = self.db.execute_query(delete_guest_query, (guest_id,))

                # حذف السجلات المرتبطة من جدول GuestEmail
                delete_email_query = "DELETE FROM GuestEmail WHERE guest_id = ?"
                success_email = self.db.execute_query(delete_email_query, (guest_id,))

                # حذف السجلات المرتبطة من جدول GuestPhone
                delete_phone_query = "DELETE FROM GuestPhone WHERE guest_id = ?"
                success_phone = self.db.execute_query(delete_phone_query, (guest_id,))

                # التحقق من نجاح الحذف
                if success_guest and success_email and success_phone:
                    QMessageBox.information(self, "Success", "Guest deleted successfully.")
                    # إزالة الصف من الجدول
                    table.removeRow(selected_row)
                else:
                    QMessageBox.warning(self, "Error", "Failed to delete guest data.")

            except Exception as e:
                QMessageBox.critical(self, "Critical Error", f"An error occurred: {str(e)}")
