if __name__ == "__main__":
    from PyQt5.QtWidgets import QApplication
    from login_window import LoginWindow  
    app = QApplication([])  
    login_window = LoginWindow()  
    login_window.show() 
    app.exec_()  