from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, 
    QMessageBox, QComboBox, QInputDialog, QFormLayout, QHBoxLayout
)
from PyQt5.QtGui import QFont, QIcon
from PyQt5.QtCore import Qt
from database_connector import DatabaseConnector
from admin_dashboard import AdminDashboard
from staff_dashboard import StaffDashboard
from guest_dashboard import GuestDashboard

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.db = DatabaseConnector()
        self.db.connect()
        self.init_ui()

    def init_ui(self):
        # Set window title and size
        self.setWindowTitle("Hotel Management System - Login")
        self.setGeometry(100, 100, 600, 500)  # Larger window size
        self.setStyleSheet("""
            background-color: #e3e3e3;  /* Background color from the palette */
            font-family: Arial, sans-serif;
        """)

        # Main layout
        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setAlignment(Qt.AlignCenter)

        # Title label
        self.title_label = QLabel("Welcome to Hotel Management System")
        self.title_label.setStyleSheet("""
            font-size: 24px;
            font-weight: bold;
            color: white;
        """)
        layout.addWidget(self.title_label, alignment=Qt.AlignCenter)

        # Form layout for inputs
        form_layout = QFormLayout()
        form_layout.setSpacing(15)

        # Email input
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("Enter your email")
        self.email_input.setStyleSheet("""
            padding: 10px;
            border: 1px solid #D2CEB2;
            border-radius: 10px;
            background-color: #D2CEB2;
            color: #000000;
        """)
        form_layout.addRow(QLabel("Email:"), self.email_input)

        # Password input
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setPlaceholderText("Enter your password")
        self.password_input.setStyleSheet("""
            padding: 10px;
            border: 1px solid #D2CEB2;
            border-radius: 10px;
            background-color: #D2CEB2;
            color: #000000;
        """)
        form_layout.addRow(QLabel("Password:"), self.password_input)

        # Role combo box
        self.role_combo = QComboBox()
        self.role_combo.addItems(["Admin", "Staff", "Guest"])
        self.role_combo.setStyleSheet("""
            padding: 10px;
            border: 1px solid #D2CEB2;
            border-radius: 10px;
            background-color: #D2CEB2;
            color: #000000;
        """)
        form_layout.addRow(QLabel("Role:"), self.role_combo)

        layout.addLayout(form_layout)

        # Login button
        self.login_button = QPushButton("Login")
        self.login_button.setStyleSheet("""
            background-color: #0C3AA2;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 15px;
            font-size: 18px;
            min-width: 200px;
            min-height: 50px;
        """)
        self.login_button.setCursor(Qt.PointingHandCursor)
        self.login_button.clicked.connect(self.handle_login)
        layout.addWidget(self.login_button, alignment=Qt.AlignCenter)

        # Register button
        self.register_button = QPushButton("Register as a New Guest")
        self.register_button.setStyleSheet("""
            background-color: #2DA9DC;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 15px;
            font-size: 18px;
            min-width: 200px;
            min-height: 50px;
        """)
        self.register_button.setCursor(Qt.PointingHandCursor)
        self.register_button.clicked.connect(self.handle_register)
        layout.addWidget(self.register_button, alignment=Qt.AlignCenter)

        self.setLayout(layout)

    def handle_login(self):
        email = self.email_input.text()
        password = self.password_input.text()
        role = self.role_combo.currentText()

        if not email or not password:
            QMessageBox.warning(self, "Error", "Please enter both email and password.")
            return

        if role == "Admin":
            query = """
                SELECT a.admin_id 
                FROM Admin a
                INNER JOIN AdminEmail ae ON a.admin_id = ae.admin_id
                WHERE ae.email = ? AND a.password = ?
            """
            params = (email, password)
        elif role == "Staff":
            query = """
                SELECT s.staff_id 
                FROM Staff s
                INNER JOIN StaffEmail se ON s.staff_id = se.staff_id
                WHERE se.email = ? AND s.password = ?
            """
            params = (email, password)
        elif role == "Guest":
            query = """
                SELECT g.guest_id 
                FROM Guest g
                INNER JOIN GuestEmail ge ON g.guest_id = ge.guest_id
                WHERE ge.email = ? AND g.password = ?
            """
            params = (email, password)

        result = self.db.fetch_data(query, params)

        if result:
            user_id = result[0][0]
            if role == "Admin":
                self.admin_id = user_id 
                self.open_admin_dashboard(user_id)
            elif role == "Staff":
                self.open_staff_dashboard(user_id)
            elif role == "Guest":
                self.open_guest_dashboard(user_id)
        else:
            QMessageBox.warning(self, "Error", "Invalid email, password, or role.")


    def handle_register(self):
        try:
            # Step 1: Collect guest data
            first_name, ok = QInputDialog.getText(self, "Register", "Enter your first name:")
            if not ok or not first_name:
                return

            last_name, ok = QInputDialog.getText(self, "Register", "Enter your last name:")
            if not ok or not last_name:
                return

            email, ok = QInputDialog.getText(self, "Register", "Enter your email:")
            if not ok or not email:
                return

            password, ok = QInputDialog.getText(self, "Register", "Enter your password:", QLineEdit.Password)
            if not ok or not password:
                return

            phone, ok = QInputDialog.getText(self, "Register", "Enter your phone number:")
            if not ok or not phone:
                return

            # Step 2: Display collected data for confirmation
            confirmation_message = (
                f"Please confirm your details:\n\n"
                f"First Name: {first_name}\n"
                f"Last Name: {last_name}\n"
                f"Email: {email}\n"
                f"Password: {'*' * len(password)}\n"  # Mask the password for security
                f"Phone Number: {phone}"
            )
            confirm_button = QMessageBox.question(
                self,
                "Confirm Registration",
                confirmation_message,
                QMessageBox.Yes | QMessageBox.No
            )

            # Step 3: Save data only if confirmed
            if confirm_button == QMessageBox.Yes:
                # Generate a new guest ID
                guest_id_result = self.db.fetch_data("SELECT MAX(guest_id) FROM Guest")
                guest_id = 1 if guest_id_result[0][0] is None else guest_id_result[0][0] + 1

                # Insert guest data into the Guest table
                guest_query = "INSERT INTO Guest (guest_id, f_name, l_name, password) VALUES (?, ?, ?, ?)"
                guest_success = self.db.execute_query(guest_query, (guest_id, first_name, last_name, password))
                if not guest_success:
                    QMessageBox.warning(self, "Error", "Failed to create account.")
                    return

                # Insert email into the GuestEmail table
                email_query = "INSERT INTO GuestEmail (guest_id, email) VALUES (?, ?)"
                email_success = self.db.execute_query(email_query, (guest_id, email))
                if not email_success:
                    QMessageBox.warning(self, "Error", "Failed to add email.")
                    return

                # Insert phone number into the GuestPhone table
                phone_query = "INSERT INTO GuestPhone (guest_id, phone) VALUES (?, ?)"
                phone_success = self.db.execute_query(phone_query, (guest_id, phone))
                if not phone_success:
                    QMessageBox.warning(self, "Error", "Failed to add phone number.")
                    return

                # Show success message
                QMessageBox.information(self, "Success", "Account created successfully!")
            else:
                # Restart registration on rejection
                QMessageBox.information(self, "Info", "Registration cancelled. Please try again.")
                self.handle_register()

        except Exception as e:
            # Display an error message if something goes wrong
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")


    def open_admin_dashboard(self, admin_id):
        self.admin_dashboard = AdminDashboard(admin_id)
        self.admin_dashboard.show()
        self.close()

    def open_staff_dashboard(self, staff_id):
        self.staff_dashboard = StaffDashboard(staff_id)
        self.staff_dashboard.show()
        self.close()

    def open_guest_dashboard(self, guest_id):
        self.guest_dashboard = GuestDashboard(guest_id)
        self.guest_dashboard.show()
        self.close()

if __name__ == "__main__":
    app = QApplication([])
    window = LoginWindow()
    window.show()
    app.exec_()