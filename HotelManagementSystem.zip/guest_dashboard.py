from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem,
    QMessageBox, QInputDialog, QLineEdit, QDesktopWidget, QGridLayout
)
from PyQt5.QtGui import QFont, QIcon, QPixmap
from PyQt5.QtCore import Qt, QSize
from database_connector import DatabaseConnector

class GuestDashboard(QWidget):
    def __init__(self, guest_id):
        super().__init__()
        self.guest_id = guest_id  
        self.db = DatabaseConnector()
        self.db.connect()
        self.init_ui()

    def style_button(self, button, bg_color, hover_color):
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg_color};
                border: none;
                border-radius: 10px;
                padding: 10px;
            }}
            QPushButton:hover {{
                background-color: {hover_color};
            }}
        """)

    def init_ui(self):
        # Set window title and size
        self.setWindowTitle("Guest Dashboard")
        self.setGeometry(100, 100, 800, 600)  # Larger window size
        self.setStyleSheet("""
            background-color: #375534;  # Background color from the palette
            font-family: Arial, sans-serif;
        """)

        # Create a grid layout for buttons
        grid_layout = QGridLayout()
        grid_layout.setSpacing(20)
        grid_layout.setAlignment(Qt.AlignTop | Qt.AlignHCenter)

        # Welcome label
        self.welcome_label = QLabel(f"Welcome, Guest {self.guest_id}!")
        self.welcome_label.setStyleSheet("""
            font-size: 24px;
            font-weight: bold;
            color: white;
        """)
        grid_layout.addWidget(self.welcome_label, 0, 0, 1, 3, alignment=Qt.AlignCenter)  # Span across 3 columns

        # Define button styles
        button_style = """
            QPushButton {
                background-color: %s;
                color: white;
                border-radius: 15px;  /* Rounded corners */
                padding: 20px;        /* Larger padding for bigger buttons */
                font-size: 18px;
                min-width: 200px;
                min-height: 70px;
            }
            QPushButton:hover {
                background-color: %s;  /* Hover effect */
            }
        """

        # View My Bookings Button
        view_bookings_button = QPushButton()
        view_bookings_button.setIcon(QIcon(QPixmap("icons/view_bookings.png")))  # Replace with actual icon path
        view_bookings_button.setIconSize(QSize(150, 150))  # Large icon size
        view_bookings_button.setStyleSheet(button_style % ("#6B9071", "#AECB30"))  # Color from palette
        view_bookings_button.clicked.connect(self.view_my_bookings)
        grid_layout.addWidget(view_bookings_button, 1, 0)

        # Make New Booking Button
        make_booking_button = QPushButton()
        make_booking_button.setIcon(QIcon(QPixmap("icons/make_booking.png")))  # Replace with actual icon path
        make_booking_button.setIconSize(QSize(150, 150))
        make_booking_button.setStyleSheet(button_style % ("#AECB30", "#E3EED4"))
        make_booking_button.clicked.connect(self.make_new_booking)
        grid_layout.addWidget(make_booking_button, 1, 1)

        # Check Room Availability Button
        check_availability_button = QPushButton()
        check_availability_button.setIcon(QIcon(QPixmap("icons/check_availability.png")))  # Replace with actual icon path
        check_availability_button.setIconSize(QSize(150, 150))
        check_availability_button.setStyleSheet(button_style % ("#E3EED4", "#6B9071"))
        check_availability_button.clicked.connect(self.check_room_availability)
        grid_layout.addWidget(check_availability_button, 1, 2)

        # Write Review Button
        write_review_button = QPushButton()
        write_review_button.setIcon(QIcon(QPixmap("icons/write_review.png")))  # Replace with actual icon path
        write_review_button.setIconSize(QSize(150, 150))
        write_review_button.setStyleSheet(button_style % ("#6B9071", "#AECB30"))
        write_review_button.clicked.connect(self.write_review)
        grid_layout.addWidget(write_review_button, 2, 0)

        # Cancel Booking Button
        cancel_booking_button = QPushButton()
        cancel_booking_button.setIcon(QIcon(QPixmap("icons/cancel_booking.png")))  # Replace with actual icon path
        cancel_booking_button.setIconSize(QSize(150, 150))
        cancel_booking_button.setStyleSheet(button_style % ("#AECB30", "#E3EED4"))
        cancel_booking_button.clicked.connect(self.cancel_booking)
        grid_layout.addWidget(cancel_booking_button, 2, 1)

        # View Room Reviews Button
        view_reviews_button = QPushButton()
        view_reviews_button.setIcon(QIcon(QPixmap("icons/view_reviews.png")))  # Replace with actual icon path
        view_reviews_button.setIconSize(QSize(150, 150))
        view_reviews_button.setStyleSheet(button_style % ("#E3EED4", "#6B9071"))
        view_reviews_button.clicked.connect(self.view_room_reviews)
        grid_layout.addWidget(view_reviews_button, 2, 2)

        # Edit Profile Button
        edit_profile_button = QPushButton()
        edit_profile_button.setIcon(QIcon(QPixmap("icons/edit_profile.png")))  # Replace with actual icon path
        edit_profile_button.setIconSize(QSize(150, 150))
        edit_profile_button.setStyleSheet(button_style % ("#AECB30", "#E3EED4"))
        edit_profile_button.clicked.connect(self.edit_profile)
        grid_layout.addWidget(edit_profile_button, 3, 0)

        # Logout Button
        logout_button = QPushButton()
        logout_button.setIcon(QIcon(QPixmap("icons/logout.png")))  # Replace with actual icon path
        logout_button.setIconSize(QSize(100, 100))
        logout_button.setStyleSheet(button_style % ("#E3EED4", "#6B9071"))
        logout_button.clicked.connect(self.logout)
        grid_layout.addWidget(logout_button, 3, 1)

        # Set the grid layout as the main layout
        self.setLayout(grid_layout)

    def logout(self):
        from utils import logout  # استيراد وظيفة logout
        logout(self)

    def view_my_bookings(self):
        query = """
            SELECT b.booking_id, r.room_number, b.check_in_date, b.check_out_date, b.total_price, b.booking_status 
            FROM Booking b
            INNER JOIN Room r ON b.room_id = r.room_id
            WHERE b.guest_id = ?
        """
        bookings = self.db.fetch_data(query, (self.guest_id,))
        if not bookings:
            QMessageBox.information(self, "Info", "No bookings found.")
            return
        self.booking_window = QWidget()
        self.booking_window.setWindowTitle("My Bookings")
        self.booking_window.setGeometry(200, 200, 800, 400)
        layout = QVBoxLayout()
        table = QTableWidget()
        table.setRowCount(len(bookings))
        table.setColumnCount(6)
        table.setHorizontalHeaderLabels(["Booking ID", "Room Number", "Check-In Date", "Check-Out Date", "Total Price", "Status"])
        for row, booking in enumerate(bookings):
            for col, value in enumerate(booking):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        layout.addWidget(table)
        self.booking_window.setLayout(layout)
        self.booking_window.show()

    def make_new_booking(self):
        try:
            available_rooms_query = "SELECT room_id, room_number, room_price FROM Room WHERE room_status = 'available'"
            available_rooms = self.db.fetch_data(available_rooms_query)
            if not available_rooms:
                QMessageBox.warning(self, "Error", "No available rooms found.")
                return
            self.room_selection_window = QWidget()
            self.room_selection_window.setWindowTitle("Available Rooms")
            self.room_selection_window.setGeometry(200, 200, 600, 400)
            layout = QVBoxLayout()
            table = QTableWidget()
            table.setRowCount(len(available_rooms))
            table.setColumnCount(3)
            table.setHorizontalHeaderLabels(["Room ID", "Room Number", "Price Per Night"])
            for row, room in enumerate(available_rooms):
                for col, value in enumerate(room):
                    table.setItem(row, col, QTableWidgetItem(str(value)))
            layout.addWidget(table)
            confirm_button = QPushButton("Confirm Room Selection")
            self.style_button(confirm_button, "#28a745", "#218838")
            confirm_button.clicked.connect(lambda: self.confirm_room_selection_with_payment(table))
            layout.addWidget(confirm_button)
            self.room_selection_window.setLayout(layout)
            self.room_selection_window.show()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
            

    def confirm_room_selection_with_payment(self, table):
        try:
            selected_row = table.currentRow()
            if selected_row == -1:
                QMessageBox.warning(self, "Error", "Please select a room to proceed.")
                return

            room_id = table.item(selected_row, 0).text()
            room_number = table.item(selected_row, 1).text()
            price_per_night = float(table.item(selected_row, 2).text())

            check_in_date, ok = QInputDialog.getText(self, "Make Booking", "Enter check-in date (YYYY-MM-DD):")
            if not ok or not check_in_date:
                return

            check_out_date, ok = QInputDialog.getText(self, "Make Booking", "Enter check-out date (YYYY-MM-DD):")
            if not ok or not check_out_date:
                return

            total_price = self.calculate_total_price(check_in_date, check_out_date, price_per_night)

            payment_confirmation, ok = QInputDialog.getItem(
                self,
                "Confirm Payment",
                f"The total price for your booking is ${total_price:.2f}. Do you want to pay now?",
                ["Yes", "No"]
            )
            if not ok or payment_confirmation != "Yes":
                QMessageBox.warning(self, "Error", "Payment not confirmed. Booking cancelled.")
                return

            # Get admin_id for the selected room
            admin_id_result = self.db.fetch_data("SELECT admin_id FROM Room WHERE room_id = ?", (room_id,))
            if not admin_id_result or admin_id_result[0][0] is None:
                QMessageBox.warning(self, "Error", "Failed to retrieve admin for this room.")
                return
            admin_id = admin_id_result[0][0]

            # Get list of staff to choose from
            staff_list = self.db.fetch_data("SELECT staff_id, name FROM Staff")
            if not staff_list:
                QMessageBox.warning(self, "Error", "No staff found to assign.")
                return
            staff_display = [f"{staff_id} - {name}" for staff_id, name in staff_list]
            selected_staff, ok = QInputDialog.getItem(
                self,
                "Assign Staff",
                "Select a staff member to assign for this booking:",
                staff_display,
                editable=False
            )
            if not ok or not selected_staff:
                return
            staff_id = int(selected_staff.split(" - ")[0])

            # Create booking
            booking_query = """
                INSERT INTO Booking (booking_id, guest_id, room_id, check_in_date, check_out_date, total_price, booking_status, admin_id, staff_id) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            booking_id_result = self.db.fetch_data("SELECT MAX(booking_id) FROM Booking")
            booking_id = 1 if booking_id_result[0][0] is None else booking_id_result[0][0] + 1

            success = self.db.execute_query(
                booking_query,
                (booking_id, self.guest_id, room_id, check_in_date, check_out_date, total_price, "confirmed", admin_id, staff_id)
            )

            if success:
                # Update room status
                update_room_status_query = "UPDATE Room SET room_status = 'occupied' WHERE room_id = ?"
                self.db.execute_query(update_room_status_query, (room_id,))

                # Insert into Payment
                from datetime import datetime
                current_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                payment_id_result = self.db.fetch_data("SELECT MAX(payment_id) FROM Payment")
                payment_id = 1 if payment_id_result[0][0] is None else payment_id_result[0][0] + 1

                payment_query = """
                    INSERT INTO Payment (payment_id, booking_id, guest_id, payment_date, payment_amount, payment_status, admin_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """
                self.db.execute_query(payment_query, (
                    payment_id, booking_id, self.guest_id, current_timestamp, total_price, "paid", admin_id
                ))

                QMessageBox.information(self, "Success", f"Booking created successfully for room {room_number}. Payment confirmed.")
                self.room_selection_window.close()
            else:
                QMessageBox.warning(self, "Error", "Failed to create booking.")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")



    def calculate_total_price(self, check_in_date, check_out_date, price_per_night):
        from datetime import datetime
        check_in = datetime.strptime(check_in_date, "%Y-%m-%d")
        check_out = datetime.strptime(check_out_date, "%Y-%m-%d")
        days = (check_out - check_in).days
        return days * price_per_night

    def check_room_availability(self):
        query = "SELECT room_number, room_status, room_price FROM Room WHERE room_status = 'available'"
        rooms = self.db.fetch_data(query)
        if not rooms:
            QMessageBox.information(self, "Info", "No available rooms found.")
            return
        self.availability_window = QWidget()
        self.availability_window.setWindowTitle("Available Rooms")
        self.availability_window.setGeometry(200, 200, 600, 400)
        layout = QVBoxLayout()
        table = QTableWidget()
        table.setRowCount(len(rooms))
        table.setColumnCount(3)
        table.setHorizontalHeaderLabels(["Room Number", "Status", "Price Per Night"])
        for row, room in enumerate(rooms):
            for col, value in enumerate(room):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        layout.addWidget(table)
        self.availability_window.setLayout(layout)
        self.availability_window.show()

    def write_review(self):
        try:
            booking_id_text, ok = QInputDialog.getText(self, "Write Review", "Enter your Booking ID:")
            if not ok or not booking_id_text:
                return

            if not booking_id_text.isdigit():
                QMessageBox.warning(self, "Error", "Booking ID must be a number.")
                return

            booking_id = int(booking_id_text)

            # تأكد أن الحجز يخص المستخدم وحالته confirmed
            check_query = "SELECT room_id FROM Booking WHERE booking_id = ? AND guest_id = ? AND booking_status = 'confirmed'"
            result = self.db.fetch_data(check_query, (booking_id, self.guest_id))

            if not result:
                QMessageBox.warning(self, "Error", "Invalid or unconfirmed booking ID.")
                return

            room_id = result[0][0]

            # خذ التعليق والتقييم
            comment, ok = QInputDialog.getText(self, "Write Review", "Enter your review:", QLineEdit.Normal)
            if not ok or not comment:
                return

            rating, ok = QInputDialog.getInt(self, "Write Review", "Enter rating (1-5):", min=1, max=5)
            if not ok:
                return

            review_id_result = self.db.fetch_data("SELECT MAX(review_id) FROM Review")
            review_id = 1 if review_id_result[0][0] is None else review_id_result[0][0] + 1

            insert_query = """
                INSERT INTO Review (review_id, comment, rating, guest_id, room_id, booking_id, admin_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """
            success = self.db.execute_query(insert_query, (review_id, comment, rating, self.guest_id, room_id, booking_id, 1))

            if success:
                QMessageBox.information(self, "Success", "Review submitted successfully.")
            else:
                QMessageBox.warning(self, "Error", "Failed to submit review.")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")

    def cancel_booking(self):
        booking_id, ok = QInputDialog.getInt(self, "Cancel Booking", "Enter booking ID to cancel:")
        if not ok:
            return
        try:
            check_booking_query = "SELECT room_id, booking_status FROM Booking WHERE booking_id = ? AND guest_id = ?"
            booking_result = self.db.fetch_data(check_booking_query, (booking_id, self.guest_id))
            if not booking_result:
                QMessageBox.warning(self, "Error", "Invalid booking ID or you don't have permission to cancel this booking.")
                return
            room_id, booking_status = booking_result[0]
            if booking_status == "cancelled":
                QMessageBox.warning(self, "Error", "This booking is already cancelled.")
                return
            update_booking_query = "UPDATE Booking SET booking_status = 'cancelled' WHERE booking_id = ? AND guest_id = ?"
            booking_success = self.db.execute_query(update_booking_query, (booking_id, self.guest_id))
            if not booking_success:
                QMessageBox.warning(self, "Error", "Failed to cancel the booking.")
                return
            update_room_status_query = "UPDATE Room SET room_status = 'available' WHERE room_id = ?"
            room_success = self.db.execute_query(update_room_status_query, (room_id,))
            if room_success:
                QMessageBox.information(self, "Success", f"Booking {booking_id} cancelled successfully. Room status updated to 'available'.")
            else:
                QMessageBox.warning(self, "Error", "Failed to update room status.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")

    def view_room_reviews(self):
        try:
            room_id, ok = QInputDialog.getInt(self, "View Room Reviews", "Enter room ID to view reviews:")
            if not ok:
                return
            query = "SELECT comment, rating FROM Review WHERE room_id = ?"
            reviews = self.db.fetch_data(query, (room_id,))
            if not reviews:
                QMessageBox.information(self, "Info", "No reviews found for this room.")
                return
            self.reviews_window = QWidget()
            self.reviews_window.setWindowTitle("Room Reviews")
            self.reviews_window.setGeometry(200, 200, 600, 400)
            layout = QVBoxLayout()
            table = QTableWidget()
            table.setRowCount(len(reviews))
            table.setColumnCount(2)
            table.setHorizontalHeaderLabels(["Comment", "Rating"])
            for row, review in enumerate(reviews):
                for col, value in enumerate(review):
                    table.setItem(row, col, QTableWidgetItem(str(value)))
            layout.addWidget(table)
            self.reviews_window.setLayout(layout)
            self.reviews_window.show()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")


    def edit_profile(self):
        try:
            # Fetch current profile data
            query = """
                SELECT g.f_name, g.l_name, g.password, ge.email, gp.phone
                FROM Guest g
                LEFT JOIN GuestEmail ge ON g.guest_id = ge.guest_id
                LEFT JOIN GuestPhone gp ON g.guest_id = gp.guest_id
                WHERE g.guest_id = ?
            """
            profile_data = self.db.fetch_data(query, (self.guest_id,))
            if not profile_data:
                QMessageBox.warning(self, "Error", "Failed to fetch profile data.")
                return

            # Extract profile data (handle missing email/phone)
            f_name, l_name, password, email, phone = profile_data[0]
            email = email if email else ""  # Default to empty string if email is None
            phone = str(phone) if phone else ""  # Default to empty string if phone is None

            # Prompt user to edit profile fields
            f_name, ok = QInputDialog.getText(self, "Edit Profile", "First Name:", QLineEdit.Normal, f_name)
            if not ok:
                return
            l_name, ok = QInputDialog.getText(self, "Edit Profile", "Last Name:", QLineEdit.Normal, l_name)
            if not ok:
                return
            password, ok = QInputDialog.getText(self, "Edit Profile", "Password:", QLineEdit.Password, password)
            if not ok:
                return
            email, ok = QInputDialog.getText(self, "Edit Profile", "Email:", QLineEdit.Normal, email)
            if not ok:
                return
            phone, ok = QInputDialog.getText(self, "Edit Profile", "Phone Number:", QLineEdit.Normal, phone)
            if not ok:
                return

            # Update Guest table
            update_guest_query = """
                UPDATE Guest 
                SET f_name = ?, l_name = ?, password = ? 
                WHERE guest_id = ?
            """
            success_guest = self.db.execute_query(update_guest_query, (f_name, l_name, password, self.guest_id))
            if not success_guest:
                QMessageBox.warning(self, "Error", "Failed to update guest information.")
                return

            # Update GuestEmail table
            if email:
                check_email_query = "SELECT email_id FROM GuestEmail WHERE guest_id = ?"
                email_result = self.db.fetch_data(check_email_query, (self.guest_id,))
                if email_result:
                    # Update existing email record
                    update_email_query = "UPDATE GuestEmail SET email = ? WHERE guest_id = ?"
                    success_email = self.db.execute_query(update_email_query, (email, self.guest_id))
                else:
                    # Insert new email record
                    insert_email_query = "INSERT INTO GuestEmail (guest_id, email) VALUES (?, ?)"
                    success_email = self.db.execute_query(insert_email_query, (self.guest_id, email))
                if not success_email:
                    QMessageBox.warning(self, "Error", "Failed to update email.")
                    return

            # Update GuestPhone table
            if phone:
                check_phone_query = "SELECT phone_id FROM GuestPhone WHERE guest_id = ?"
                phone_result = self.db.fetch_data(check_phone_query, (self.guest_id,))
                if phone_result:
                    # Update existing phone record
                    update_phone_query = "UPDATE GuestPhone SET phone = ? WHERE guest_id = ?"
                    success_phone = self.db.execute_query(update_phone_query, (phone, self.guest_id))
                else:
                    # Insert new phone record
                    insert_phone_query = "INSERT INTO GuestPhone (guest_id, phone) VALUES (?, ?)"
                    success_phone = self.db.execute_query(insert_phone_query, (self.guest_id, phone))
                if not success_phone:
                    QMessageBox.warning(self, "Error", "Failed to update phone number.")
                    return

            # Show success message
            QMessageBox.information(self, "Success", "Profile updated successfully.")

        except Exception as e:
            # Display an error message if something goes wrong
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")



if __name__ == "__main__":
    from PyQt5.QtWidgets import QApplication
    app = QApplication([])
    window = GuestDashboard(guest_id=1)  
    window.show()
    app.exec_()