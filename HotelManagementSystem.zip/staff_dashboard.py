from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem,
    QMessageBox, QInputDialog, QLineEdit, QDesktopWidget, QGridLayout
)
from PyQt5.QtGui import QFont, QIcon, QPixmap
from PyQt5.QtCore import Qt, QSize
from database_connector import DatabaseConnector

class StaffDashboard(QWidget):
    def __init__(self, staff_id):
        super().__init__()
        self.staff_id = staff_id  
        self.db = DatabaseConnector()
        self.db.connect()
        self.init_ui()

    def init_ui(self):
        # Set window title and size
        self.setWindowTitle("Staff Dashboard")
        self.setGeometry(100, 100, 800, 600)  # Larger window size
        self.setStyleSheet("""
            background-color: #A33757;  # Background color from the palette
            font-family: Arial, sans-serif;
        """)

        # Create a grid layout for buttons
        grid_layout = QGridLayout()
        grid_layout.setSpacing(20)
        grid_layout.setAlignment(Qt.AlignTop | Qt.AlignHCenter)

        # Welcome label
        self.welcome_label = QLabel(f"Welcome, Staff {self.staff_id}!")
        self.welcome_label.setStyleSheet("""
            font-size: 24px;
            font-weight: bold;
            color: white;
        """)
        grid_layout.addWidget(self.welcome_label, 0, 0, 1, 3, alignment=Qt.AlignCenter)  # Span across 3 columns

        # Define button styles
        button_style = """
            QPushButton {
                background-color: %s;
                color: white;
                border-radius: 15px;  /* Rounded corners */
                padding: 20px;        /* Larger padding for bigger buttons */
                font-size: 18px;
                min-width: 200px;
                min-height: 70px;
            }
            QPushButton:hover {
                background-color: %s;  /* Hover effect */
            }
        """

        # View Assigned Bookings Button
        view_assigned_bookings_button = QPushButton()
        view_assigned_bookings_button.setIcon(QIcon(QPixmap("icons/view_assigned_bookings.png")))  # Replace with actual icon path
        view_assigned_bookings_button.setIconSize(QSize(150,150))  # Large icon size
        view_assigned_bookings_button.setStyleSheet(button_style % ("#FFB9B4", "#FB9590"))  # Color from palette
        view_assigned_bookings_button.clicked.connect(self.view_assigned_bookings)
        grid_layout.addWidget(view_assigned_bookings_button, 1, 0)

        # Update Room Status Button
        update_room_status_button = QPushButton()
        update_room_status_button.setIcon(QIcon(QPixmap("icons/update_room_status.png")))  # Replace with actual icon path
        update_room_status_button.setIconSize(QSize(150,150))
        update_room_status_button.setStyleSheet(button_style % ("#DC586D", "#A33757"))
        update_room_status_button.clicked.connect(self.manage_rooms)
        grid_layout.addWidget(update_room_status_button, 1, 1)

        # Cancel Booking Button
        cancel_booking_button = QPushButton()
        cancel_booking_button.setIcon(QIcon(QPixmap("icons/cancel_booking.png")))  # Replace with actual icon path
        cancel_booking_button.setIconSize(QSize(150,150))
        cancel_booking_button.setStyleSheet(button_style % ("#852E4E", "#4C1D3D"))
        cancel_booking_button.clicked.connect(self.cancel_booking)
        grid_layout.addWidget(cancel_booking_button, 1, 2)

        # View Rooms Button
        view_rooms_button = QPushButton()
        view_rooms_button.setIcon(QIcon(QPixmap("icons/view_rooms.png")))  # Replace with actual icon path
        view_rooms_button.setIconSize(QSize(150,150))
        view_rooms_button.setStyleSheet(button_style % ("#FB9590", "#FFB9B4"))
        view_rooms_button.clicked.connect(self.view_rooms)
        grid_layout.addWidget(view_rooms_button, 2, 0)

        # Logout Button
        logout_button = QPushButton()
        logout_button.setIcon(QIcon(QPixmap("icons/logout.png")))  # Replace with actual icon path
        logout_button.setIconSize(QSize(100,100))
        logout_button.setStyleSheet(button_style % ("#4C1D3D", "#852E4E"))
        logout_button.clicked.connect(self.logout)
        grid_layout.addWidget(logout_button, 2, 1)

        # Set the grid layout as the main layout
        self.setLayout(grid_layout)


    def logout(self):
        from utils import logout  # استيراد وظيفة logout
        logout(self)

    def view_assigned_bookings(self):
        query = "SELECT booking_id, room_id, guest_id, total_price, booking_status FROM Booking WHERE staff_id = ?"
        bookings = self.db.fetch_data(query, (self.staff_id,))
        if not bookings:
            QMessageBox.information(self, "Info", "No assigned bookings found.")
            return

        self.booking_window = QWidget()
        self.booking_window.setWindowTitle("Assigned Bookings")
        self.booking_window.setGeometry(200, 200, 800, 400)

        layout = QVBoxLayout()
        table = QTableWidget()
        table.setRowCount(len(bookings))
        table.setColumnCount(5)
        table.setHorizontalHeaderLabels(["Booking ID", "Room ID", "Guest ID", "Total Price", "Status"])
        for row, booking in enumerate(bookings):
            for col, value in enumerate(booking):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        layout.addWidget(table)
        self.booking_window.setLayout(layout)
        self.booking_window.show()

    def manage_rooms(self):
        query = "SELECT room_id, room_number, room_status FROM Room"
        rooms = self.db.fetch_data(query)
        if not rooms:
            QMessageBox.information(self, "Info", "No rooms found.")
            return

        self.room_window = QWidget()
        self.room_window.setWindowTitle("Manage Rooms")
        self.room_window.setGeometry(200, 200, 600, 400)

        layout = QVBoxLayout()
        table = QTableWidget()
        table.setRowCount(len(rooms))
        table.setColumnCount(3)
        table.setHorizontalHeaderLabels(["Room ID", "Room Number", "Status"])
        for row, room in enumerate(rooms):
            for col, value in enumerate(room):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        layout.addWidget(table)

        update_button = QPushButton("Update Room Status")
        update_button.setStyleSheet("""
            QPushButton {
                background-color: #17a2b8;
                color: white;
                border-radius: 10px;
                padding: 10px;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #138496;
            }
        """)
        update_button.clicked.connect(lambda: self.update_room_status(table))
        layout.addWidget(update_button)

        self.room_window.setLayout(layout)
        self.room_window.show()

    def update_room_status(self, table):
        selected_row = table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Error", "Please select a room to update.")
            return

        room_id = table.item(selected_row, 0).text()
        new_status, ok = QInputDialog.getItem(self, "Update Status", "Select new status:", ["available", "occupied", "under_maintenance"])
        if not ok or not new_status:
            return

        query_update_room = "UPDATE Room SET room_status = ? WHERE room_id = ?"
        success_room = self.db.execute_query(query_update_room, (new_status, room_id))
        if not success_room:
            QMessageBox.warning(self, "Error", "Failed to update room status.")
            return

        if new_status == 'available':
            booking_query = "SELECT booking_id FROM Booking WHERE room_id = ? AND booking_status = 'confirmed'"
            bookings = self.db.fetch_data(booking_query, (room_id,))
            if bookings:
                for booking in bookings:
                    booking_id = booking[0]
                    update_booking_query = "UPDATE Booking SET booking_status = 'cancelled' WHERE booking_id = ?"
                    success_booking = self.db.execute_query(update_booking_query, (booking_id,))
                    if not success_booking:
                        QMessageBox.warning(self, "Error", f"Failed to cancel booking {booking_id}.")
                        continue
                    QMessageBox.information(self, "Success", f"Room {room_id} updated to 'available'. Booking {booking_id} cancelled.")

        QMessageBox.information(self, "Success", "Room status updated successfully.")

    def cancel_booking(self):
        booking_id, ok = QInputDialog.getText(self, "Cancel Booking", "Enter Booking ID to cancel:")
        if not ok or not booking_id:
            return

        query = "UPDATE Booking SET booking_status = 'cancelled' WHERE booking_id = ?"
        success = self.db.execute_query(query, (booking_id,))

        if success:
            QMessageBox.information(self, "Success", f"Booking {booking_id} has been cancelled.")
        else:
            QMessageBox.warning(self, "Error", "Failed to cancel the booking.")

    def view_rooms(self):
        query = "SELECT room_id, room_number, room_status FROM Room"
        rooms = self.db.fetch_data(query)
        if not rooms:
            QMessageBox.information(self, "Info", "No rooms found.")
            return

        self.room_window = QWidget()
        self.room_window.setWindowTitle("Room Data")
        self.room_window.setGeometry(200, 200, 600, 400)

        layout = QVBoxLayout()
        table = QTableWidget()
        table.setRowCount(len(rooms))
        table.setColumnCount(3)
        table.setHorizontalHeaderLabels(["Room ID", "Room Number", "Status"])
        for row, room in enumerate(rooms):
            for col, value in enumerate(room):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        layout.addWidget(table)
        self.room_window.setLayout(layout)
        self.room_window.show()

if __name__ == "__main__":
    from PyQt5.QtWidgets import QApplication
    app = QApplication([])
    window = StaffDashboard(staff_id=1)  
    window.show()
    app.exec_()