import pyodbc

class DatabaseConnector:
    def __init__(self):
        self.conn = None

    def connect(self):
        try:
            self.conn = pyodbc.connect(
                "Driver={SQL Server};"
                "Server=ABDELRHMAN;"  
                "DATABASE=HSDB;"      
                "Trusted_Connection=yes;"
            )
            print("Connected to the database successfully!")
        except Exception as e:
            print(f"Error connecting to the database: {e}")

    def execute_query(self, query, params=None):
        cursor = self.conn.cursor()
        try:
            print(f"Executing query: {query} with params: {params}") 
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Error executing query: {e}")  
            return False

    def fetch_data(self, query, params=None):
        cursor = self.conn.cursor()
        try:
            print(f"Fetching data with query: {query} and params: {params}") 
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            return cursor.fetchall()
        except Exception as e:
            print(f"Error fetching data: {e}") 
            return []