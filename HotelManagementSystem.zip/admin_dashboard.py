from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem, 
    QMessageBox, QInputDialog, QLineEdit, QDesktopWidget, QGridLayout
)
from PyQt5.QtGui import QFont, QIcon, QPixmap
from PyQt5.QtCore import Qt, QSize
from database_connector import DatabaseConnector

class AdminDashboard(QWidget):
    def __init__(self, admin_id):
        super().__init__()
        self.admin_id = admin_id   # ← خزنه هنا
        self.db = DatabaseConnector()
        self.db.connect()
        self.init_ui()

    def init_ui(self):
        # Set window title and size
        self.setWindowTitle("Admin Dashboard")
        self.setGeometry(100, 100, 800, 600)  # Larger window size
        self.setStyleSheet("""
            background-color: #0A7075;  # Background color from the palette
            font-family: Arial, sans-serif;
        """)

        # Create a grid layout for buttons
        grid_layout = QGridLayout()
        grid_layout.setSpacing(20)
        grid_layout.setAlignment(Qt.AlignTop | Qt.AlignHCenter)

        # Welcome label
        self.welcome_label = QLabel("Welcome, Admin!")
        self.welcome_label.setStyleSheet("""
            font-size: 24px;
            font-weight: bold;
            color: white;
        """)
        grid_layout.addWidget(self.welcome_label, 0, 0, 1, 3, alignment=Qt.AlignCenter)  # Span across 3 columns

        # Define button styles
        button_style = """
            QPushButton {
                background-color: %s;
                color: white;
                border-radius: 15px;  /* Rounded corners */
                padding: 20px;        /* Larger padding for bigger buttons */
                font-size: 18px;
                min-width: 200px;
                min-height: 70px;
            }
            QPushButton:hover {
                background-color: %s;  /* Hover effect */
            }
        """

        # View All Bookings Button
        view_bookings_button = QPushButton()
        view_bookings_button.setIcon(QIcon(QPixmap("icons/view_bookings.png")))  # Replace with actual icon path
        view_bookings_button.setIconSize(QSize(150, 150))  # Large icon size
        view_bookings_button.setStyleSheet(button_style % ("#0C969C", "#0A7075"))  # Color from palette
        view_bookings_button.clicked.connect(self.view_all_bookings)
        grid_layout.addWidget(view_bookings_button, 1, 0)

        # Manage Rooms Button
        manage_rooms_button = QPushButton()
        manage_rooms_button.setIcon(QIcon(QPixmap("icons/manage_rooms.png")))  # Replace with actual icon path
        manage_rooms_button.setIconSize(QSize(150,150))
        manage_rooms_button.setStyleSheet(button_style % ("#6BA3BE", "#0C969C"))
        manage_rooms_button.clicked.connect(self.manage_rooms)
        grid_layout.addWidget(manage_rooms_button, 1, 1)

        # Manage Staff Button
        manage_staff_button = QPushButton()
        manage_staff_button.setIcon(QIcon(QPixmap("icons/manage_staff.png")))  # Replace with actual icon path
        manage_staff_button.setIconSize(QSize(150,150))
        manage_staff_button.setStyleSheet(button_style % ("#27D600", "#6BA3BE"))
        manage_staff_button.clicked.connect(self.manage_staff)
        grid_layout.addWidget(manage_staff_button, 1, 2)

        # Add New Staff Button
        add_staff_button = QPushButton()
        add_staff_button.setIcon(QIcon(QPixmap("icons/add_staff.png")))  # Replace with actual icon path
        add_staff_button.setIconSize(QSize(150,150))
        add_staff_button.setStyleSheet(button_style % ("#032F30", "#27D600"))
        add_staff_button.clicked.connect(self.add_new_staff)
        grid_layout.addWidget(add_staff_button, 2, 0)

        # Moderate Reviews Button
        moderate_reviews_button = QPushButton()
        moderate_reviews_button.setIcon(QIcon(QPixmap("icons/moderate_reviews.png")))  # Replace with actual icon path
        moderate_reviews_button.setIconSize(QSize(150,150))
        moderate_reviews_button.setStyleSheet(button_style % ("#031716", "#032F30"))
        moderate_reviews_button.clicked.connect(self.moderate_reviews)
        grid_layout.addWidget(moderate_reviews_button, 2, 1)

        # Generate Reports Button
        generate_reports_button = QPushButton()
        generate_reports_button.setIcon(QIcon(QPixmap("icons/generate_reports.png")))  # Replace with actual icon path
        generate_reports_button.setIconSize(QSize(150,150))
        generate_reports_button.setStyleSheet(button_style % ("#27D600", "#031716"))
        generate_reports_button.clicked.connect(self.generate_reports)
        grid_layout.addWidget(generate_reports_button, 2, 2)

        # Total Earnings Button
        total_earnings_button = QPushButton()
        total_earnings_button.setIcon(QIcon(QPixmap("icons/total_earnings.png")))  # Replace with actual icon path
        total_earnings_button.setIconSize(QSize(150,150))
        total_earnings_button.setStyleSheet(button_style % ("#0C969C", "#27D600"))
        total_earnings_button.clicked.connect(self.show_total_earnings)
        grid_layout.addWidget(total_earnings_button, 3, 0)


        # Manage Guests Button
        manage_guests_button = QPushButton()
        manage_guests_button.setIcon(QIcon(QPixmap("icons/manage_guests.png")))  # Replace with actual icon path
        manage_guests_button.setIconSize(QSize(150, 150))
        manage_guests_button.setStyleSheet(button_style % ("#FFA500", "#FF8C00"))  # Orange color
        manage_guests_button.clicked.connect(self.manage_guests)
        grid_layout.addWidget(manage_guests_button, 3, 1)

        # Logout Button
        logout_button = QPushButton()
        logout_button.setIcon(QIcon(QPixmap("icons/logout.png")))  # Replace with actual icon path
        logout_button.setIconSize(QSize(100,100))
        logout_button.setStyleSheet(button_style % ("#6BA3BE", "#0C969C"))
        logout_button.clicked.connect(self.logout)
        grid_layout.addWidget(logout_button, 3, 2)

        # Set the grid layout as the main layout
        self.setLayout(grid_layout)


    def style_button(self, button, color):
        button.setStyleSheet(f"""
            background-color: {color};
            color: white;
            padding: 15px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        """)
        button.setCursor(Qt.PointingHandCursor)

    def logout(self):
        from utils import logout  
        logout(self)

    def show_total_earnings(self):
        query = "SELECT SUM(total_price) FROM Booking WHERE booking_status = 'confirmed'"
        result = self.db.fetch_data(query)
        if result and result[0][0] is not None:
            total_earnings = result[0][0]
            QMessageBox.information(self, "Total Earnings", f"Total earnings from bookings: ${total_earnings:.2f}")
        else:
            QMessageBox.information(self, "Total Earnings", "No confirmed bookings found. Total earnings: $0.00")

    def view_all_bookings(self):
        query = "SELECT booking_id, room_id, guest_id, total_price, booking_status FROM Booking"
        bookings = self.db.fetch_data(query)
        if not bookings:
            QMessageBox.information(self, "Info", "No bookings found.")
            return

        self.booking_window = QWidget()
        self.booking_window.setWindowTitle("All Bookings")
        self.booking_window.setGeometry(200, 200, 800, 400)

        layout = QVBoxLayout()
        table = QTableWidget()
        table.setRowCount(len(bookings))
        table.setColumnCount(5)
        table.setHorizontalHeaderLabels(["Booking ID", "Room ID", "Guest ID", "Total Price", "Status"])
        for row, booking in enumerate(bookings):
            for col, value in enumerate(booking):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        layout.addWidget(table)
        self.booking_window.setLayout(layout)
        self.booking_window.show()

    def manage_staff(self):
        query = """
            SELECT s.staff_id, s.name, s.role, s.password, se.email, sp.phone
            FROM Staff s
            INNER JOIN StaffEmail se ON s.staff_id = se.staff_id
            INNER JOIN StaffPhone sp ON s.staff_id = sp.staff_id
        """
        staff_data = self.db.fetch_data(query)

        if not staff_data:
            QMessageBox.information(self, "Info", "No staff members found.")
            return

        self.staff_window = QWidget()
        self.staff_window.setWindowTitle("Manage Staff")
        self.staff_window.setGeometry(200, 200, 800, 400)
        layout = QVBoxLayout()

        table = QTableWidget()
        table.setRowCount(len(staff_data))
        table.setColumnCount(6) 
        table.setHorizontalHeaderLabels(["ID", "Name", "Role", "Password", "Email", "Phone"])

        for row, staff in enumerate(staff_data):
            for col, value in enumerate(staff):
                table.setItem(row, col, QTableWidgetItem(str(value)))

        layout.addWidget(table)

        edit_button = QPushButton("Edit Staff")
        self.style_button(edit_button, "#28a745")
        edit_button.clicked.connect(lambda: self.edit_staff(table))
        layout.addWidget(edit_button)

        delete_button = QPushButton("Delete Staff")
        self.style_button(delete_button, "#dc3545")
        delete_button.clicked.connect(lambda: self.delete_staff(table))
        layout.addWidget(delete_button)

        self.staff_window.setLayout(layout)
        self.staff_window.show()

    def edit_staff(self, table):
        """تعديل بيانات موظف."""
        selected_row = table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Error", "Please select a staff member to edit.")
            return

        staff_id = table.item(selected_row, 0).text()
        current_name = table.item(selected_row, 1).text()
        current_role = table.item(selected_row, 2).text()
        current_password = table.item(selected_row, 3).text()
        current_email = table.item(selected_row, 4).text()
        current_phone = table.item(selected_row, 5).text()

        name, ok = QInputDialog.getText(self, "Edit Staff", "Enter new name:", text=current_name)
        if not ok or not name:
            return

        role, ok = QInputDialog.getItem(self, "Edit Staff", "Select new role:", ["manager", "receptionist"], current=0 if current_role == "manager" else 1)
        if not ok or not role:
            return

        email, ok = QInputDialog.getText(self, "Edit Staff", "Enter new email:", text=current_email)
        if not ok or not email:
            return

        phone, ok = QInputDialog.getText(self, "Edit Staff", "Enter new phone number:", text=current_phone)
        if not ok or not phone:
            return

        password, ok = QInputDialog.getText(self, "Edit Staff", "Enter new password (leave blank to keep current):", QLineEdit.Password)
        if not ok:
            return

        update_staff_query = "UPDATE Staff SET name = ?, role = ? WHERE staff_id = ?"
        update_email_query = "UPDATE StaffEmail SET email = ? WHERE staff_id = ?"
        update_phone_query = "UPDATE StaffPhone SET phone = ? WHERE staff_id = ?"

        success_staff = self.db.execute_query(update_staff_query, (name, role, staff_id))
        success_email = self.db.execute_query(update_email_query, (email, staff_id))
        success_phone = self.db.execute_query(update_phone_query, (phone, staff_id))

        if password:
            update_password_query = "UPDATE Staff SET password = ? WHERE staff_id = ?"
            success_password = self.db.execute_query(update_password_query, (password, staff_id))
            if not success_password:
                QMessageBox.warning(self, "Error", "Failed to update password.")
                return

        if success_staff and success_email and success_phone:
            QMessageBox.information(self, "Success", "Staff data updated successfully.")

            table.item(selected_row, 1).setText(name)
            table.item(selected_row, 2).setText(role)
            table.item(selected_row, 4).setText(email)
            table.item(selected_row, 5).setText(phone)

        else:
            QMessageBox.warning(self, "Error", "Failed to update staff data.")
    def delete_staff(self, table):
        """حذف موظف."""
        selected_row = table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Error", "Please select a staff member to delete.")
            return

        staff_id = table.item(selected_row, 0).text()

        confirm = QMessageBox.question(
            self,
            "Confirm Deletion",
            f"Are you sure you want to delete staff member with ID {staff_id}?",
            QMessageBox.Yes | QMessageBox.No
        )

        if confirm == QMessageBox.Yes:
            delete_staff_query = "DELETE FROM Staff WHERE staff_id = ?"
            delete_email_query = "DELETE FROM StaffEmail WHERE staff_id = ?"
            delete_phone_query = "DELETE FROM StaffPhone WHERE staff_id = ?"

            success_staff = self.db.execute_query(delete_staff_query, (staff_id,))
            success_email = self.db.execute_query(delete_email_query, (staff_id,))
            success_phone = self.db.execute_query(delete_phone_query, (staff_id,))

            if success_staff and success_email and success_phone:
                QMessageBox.information(self, "Success", "Staff member deleted successfully.")
                table.removeRow(selected_row)
            else:
                QMessageBox.warning(self, "Error", "Failed to delete staff member.")




    def manage_guests(self):
        query = """
            SELECT g.guest_id, g.f_name, g.l_name, gp.phone, ge.email, g.password
            FROM Guest g
            LEFT JOIN GuestPhone gp ON g.guest_id = gp.guest_id
            LEFT JOIN GuestEmail ge ON g.guest_id = ge.guest_id
        """
        guests_data = self.db.fetch_data(query)
        if not guests_data:
            QMessageBox.information(self, "Info", "No guests found.")
            return

        self.guest_window = QWidget()
        self.guest_window.setWindowTitle("Manage Guests")
        self.guest_window.setGeometry(200, 200, 800, 400)

        layout = QVBoxLayout()

        table = QTableWidget()
        table.setRowCount(len(guests_data))
        table.setColumnCount(6)
        table.setHorizontalHeaderLabels(["ID", "First Name", "Last Name", "Phone", "Email","Password"])

        for row, guest in enumerate(guests_data):
            for col, value in enumerate(guest):
                table.setItem(row, col, QTableWidgetItem(str(value) if value is not None else ""))

        layout.addWidget(table)

        edit_button = QPushButton("Edit Guest")
        self.style_button(edit_button, "#28a745")
        edit_button.clicked.connect(lambda: self.edit_guest(table))
        layout.addWidget(edit_button)

        delete_button = QPushButton("Delete Guest")
        self.style_button(delete_button, "#dc3545")
        delete_button.clicked.connect(lambda: self.delete_guest(table))
        layout.addWidget(delete_button)

        add_button = QPushButton("Add New Guest")
        self.style_button(add_button, "#007bff")
        add_button.clicked.connect(self.add_new_guest)
        layout.addWidget(add_button)

        self.guest_window.setLayout(layout)
        self.guest_window.show()




    def add_new_guest(self):
        try:
            f_name, ok = QInputDialog.getText(self, "Add Guest", "Enter first name:")
            if not ok or not f_name:
                return

            l_name, ok = QInputDialog.getText(self, "Add Guest", "Enter last name:")
            if not ok or not l_name:
                return

            phone, ok = QInputDialog.getText(self, "Add Guest", "Enter phone number:")
            if not ok:
                return

            email, ok = QInputDialog.getText(self, "Add Guest", "Enter email:")
            if not ok:
                return

            password, ok = QInputDialog.getText(self, "Add Guest", "Enter password:", QLineEdit.Password)
            if not ok or not password:
                QMessageBox.warning(self, "Error", "Password is required.")
                return

            max_guest_id_query = "SELECT MAX(guest_id) FROM Guest"
            max_guest_id_result = self.db.fetch_data(max_guest_id_query)
            guest_id = 1 if max_guest_id_result[0][0] is None else max_guest_id_result[0][0] + 1

            insert_guest_query = "INSERT INTO Guest (guest_id, f_name, l_name, password) VALUES (?, ?, ?, ?)"
            insert_phone_query = "INSERT INTO GuestPhone (guest_id, phone) VALUES (?, ?)"
            insert_email_query = "INSERT INTO GuestEmail (guest_id, email) VALUES (?, ?)"

            success_guest = self.db.execute_query(insert_guest_query, (guest_id, f_name, l_name, password))
            success_phone = self.db.execute_query(insert_phone_query, (guest_id, phone))
            success_email = self.db.execute_query(insert_email_query, (guest_id, email))

            if success_guest and success_phone and success_email:
                QMessageBox.information(self, "Success", "Guest added successfully.")
            else:
                QMessageBox.warning(self, "Error", "Failed to add guest.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")



    def delete_guest(self, table):
        selected_row = table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Error", "Please select a guest to delete.")
            return

        guest_id = table.item(selected_row, 0).text()

        confirm = QMessageBox.question(
            self,
            "Confirm Deletion",
            f"Are you sure you want to delete guest with ID {guest_id}?",
            QMessageBox.Yes | QMessageBox.No
        )

        if confirm == QMessageBox.Yes:
            try:
                # Start a transaction
                self.db.execute_query("BEGIN TRANSACTION")

                # Delete from GuestEmail table
                delete_email_query = "DELETE FROM GuestEmail WHERE guest_id = ?"
                success_email = self.db.execute_query(delete_email_query, (guest_id,))

                # Delete from GuestPhone table
                delete_phone_query = "DELETE FROM GuestPhone WHERE guest_id = ?"
                success_phone = self.db.execute_query(delete_phone_query, (guest_id,))

                # Delete from Guest table
                delete_guest_query = "DELETE FROM Guest WHERE guest_id = ?"
                success_guest = self.db.execute_query(delete_guest_query, (guest_id,))

                # Commit the transaction if all deletions succeed
                if success_email and success_phone and success_guest:
                    self.db.execute_query("COMMIT")
                    QMessageBox.information(self, "Success", "Guest deleted successfully.")
                    table.removeRow(selected_row)
                else:
                    # Rollback the transaction if any deletion fails
                    self.db.execute_query("ROLLBACK")
                    QMessageBox.warning(self, "Error", "Failed to delete guest data.")

            except Exception as e:
                # Rollback in case of an unexpected error
                self.db.execute_query("ROLLBACK")
                QMessageBox.critical(self, "Critical Error", f"An error occurred: {str(e)}")

###########

    def edit_guest(self, table):
        selected_row = table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Error", "Please select a guest to edit.")
            return

        guest_id = table.item(selected_row, 0).text()
        current_f_name = table.item(selected_row, 1).text()
        current_l_name = table.item(selected_row, 2).text()
        current_phone = table.item(selected_row, 3).text() or ""
        current_email = table.item(selected_row, 4).text() or ""
        current_password = table.item(selected_row, 5).text() or ""

        f_name, ok = QInputDialog.getText(self, "Edit Guest", "Enter new first name:", text=current_f_name)
        if not ok or not f_name:
            return

        l_name, ok = QInputDialog.getText(self, "Edit Guest", "Enter new last name:", text=current_l_name)
        if not ok or not l_name:
            return

        phone, ok = QInputDialog.getText(self, "Edit Guest", "Enter new phone number:", text=current_phone)
        if not ok:
            return

        email, ok = QInputDialog.getText(self, "Edit Guest", "Enter new email:", text=current_email)
        if not ok:
            return

        password, ok = QInputDialog.getText(self, "Edit Guest", "Enter new password (leave blank to keep current):", QLineEdit.Password)
        if not ok:
            return

        update_guest_query = "UPDATE Guest SET f_name = ?, l_name = ?, password = ? WHERE guest_id = ?"
        update_phone_query = "UPDATE GuestPhone SET phone = ? WHERE guest_id = ?"
        update_email_query = "UPDATE GuestEmail SET email = ? WHERE guest_id = ?"

        success_guest = self.db.execute_query(update_guest_query, (f_name, l_name, password or current_password, guest_id))
        success_phone = self.db.execute_query(update_phone_query, (phone, guest_id))
        success_email = self.db.execute_query(update_email_query, (email, guest_id))

        if success_guest and success_phone and success_email:
            QMessageBox.information(self, "Success", "Guest data updated successfully.")
            table.item(selected_row, 1).setText(f_name)
            table.item(selected_row, 2).setText(l_name)
            table.item(selected_row, 3).setText(phone)
            table.item(selected_row, 4).setText(email)
            table.item(selected_row, 5).setText(password or current_password)
        else:
            QMessageBox.warning(self, "Error", "Failed to update guest data.")

############


    def manage_rooms(self):
        query = "SELECT room_id, room_number, room_status, admin_id FROM Room"
        rooms = self.db.fetch_data(query)
        if not rooms:
            QMessageBox.information(self, "Info", "No rooms found.")
            return

        self.room_window = QWidget()
        self.room_window.setWindowTitle("Manage Rooms")
        self.room_window.setGeometry(200, 200, 600, 400)
        layout = QVBoxLayout()

        table = QTableWidget()
        table.setRowCount(len(rooms))
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(["Room ID", "Room Number", "Status", "Admin ID"])
        for row, room in enumerate(rooms):
            for col, value in enumerate(room):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        layout.addWidget(table)

        update_button = QPushButton("Update Room Status")
        self.style_button(update_button, "#17a2b8")
        update_button.clicked.connect(lambda: self.update_room_status(table))
        layout.addWidget(update_button)

        add_room_button = QPushButton("Add New Room")
        self.style_button(add_room_button, "#28a745") 
        add_room_button.clicked.connect(self.add_new_room)
        layout.addWidget(add_room_button)

        self.room_window.setLayout(layout)
        self.room_window.show()

    def add_new_room(self):
        try:
            room_number, ok = QInputDialog.getText(self, "Add New Room", "Enter room number:")
            if not ok or not room_number:
                return

            room_price, ok = QInputDialog.getDouble(self, "Add New Room", "Enter room price per night:", min=0)
            if not ok or room_price <= 0:
                QMessageBox.warning(self, "Error", "Please enter a valid room price.")
                return

            room_status, ok = QInputDialog.getItem(self, "Add New Room", "Select room status:", ["available", "occupied", "under_maintenance"])
            if not ok or not room_status:
                return

            # Generate new room_id
            max_room_id_query = "SELECT MAX(room_id) FROM Room"
            max_room_id_result = self.db.fetch_data(max_room_id_query)
            room_id = 1 if max_room_id_result[0][0] is None else max_room_id_result[0][0] + 1

            # Use self.admin_id
            insert_query = "INSERT INTO Room (room_id, room_number, room_price, room_status, admin_id) VALUES (?, ?, ?, ?, ?)"
            success = self.db.execute_query(insert_query, (room_id, room_number, room_price, room_status, self.admin_id))

            if success:
                QMessageBox.information(self, "Success", f"Room {room_number} added successfully.")
            else:
                QMessageBox.warning(self, "Error", "Failed to add new room.")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")


    def update_room_status(self, table):
        selected_row = table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Error", "Please select a room to update.")
            return

        room_id = table.item(selected_row, 0).text()
        new_status, ok = QInputDialog.getItem(self, "Update Status", "Select new status:", ["available", "occupied", "under_maintenance"])
        if not ok or not new_status:
            return

        query_update_room = "UPDATE Room SET room_status = ? WHERE room_id = ?"
        success_room = self.db.execute_query(query_update_room, (new_status, room_id))
        if not success_room:
            QMessageBox.warning(self, "Error", "Failed to update room status.")
            return

        if new_status == 'available':
            booking_query = "SELECT booking_id FROM Booking WHERE room_id = ? AND booking_status = 'confirmed'"
            bookings = self.db.fetch_data(booking_query, (room_id,))
            if bookings:
                for booking in bookings:
                    booking_id = booking[0]
                    update_booking_query = "UPDATE Booking SET booking_status = 'cancelled' WHERE booking_id = ?"
                    success_booking = self.db.execute_query(update_booking_query, (booking_id,))
                    if not success_booking:
                        QMessageBox.warning(self, "Error", f"Failed to cancel booking {booking_id}.")
                        continue
                    QMessageBox.information(self, "Success", f"Room {room_id} updated to 'available'. Booking {booking_id} cancelled.")

        QMessageBox.information(self, "Success", "Room status updated successfully.")

    def add_new_staff(self):
        try:
            name, ok = QInputDialog.getText(self, "Add Staff", "Enter staff name:")
            if not ok or not name:
                return

            role, ok = QInputDialog.getItem(self, "Add Staff", "Select role:", ["manager", "receptionist"])
            if not ok or not role:
                return

            password, ok = QInputDialog.getText(self, "Add Staff", "Enter password:", QLineEdit.Password)
            if not ok or not password:
                return

            email, ok = QInputDialog.getText(self, "Add Staff", "Enter email:")
            if not ok or not email:
                return

            phone, ok = QInputDialog.getText(self, "Add Staff", "Enter phone number:")
            if not ok or not phone:
                return

            max_staff_id_query = "SELECT MAX(staff_id) FROM Staff"
            max_staff_id_result = self.db.fetch_data(max_staff_id_query)
            staff_id = 1 if max_staff_id_result[0][0] is None else max_staff_id_result[0][0] + 1

            insert_staff_query = "INSERT INTO Staff (staff_id, name, role, password, admin_id) VALUES (?, ?, ?, ?, ?)"
            success = self.db.execute_query(insert_staff_query, (staff_id, name, role, password, 1))
            if not success:
                QMessageBox.warning(self, "Error", "Failed to add staff.")
                return

            insert_email_query = "INSERT INTO StaffEmail (staff_id, email) VALUES (?, ?)"
            email_success = self.db.execute_query(insert_email_query, (staff_id, email))
            if not email_success:
                QMessageBox.warning(self, "Error", "Failed to add email.")
                return

            insert_phone_query = "INSERT INTO StaffPhone (staff_id, phone) VALUES (?, ?)"
            phone_success = self.db.execute_query(insert_phone_query, (staff_id, phone))
            if not phone_success:
                QMessageBox.warning(self, "Error", "Failed to add phone number.")
                return

            QMessageBox.information(self, "Success", "Staff added successfully.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")

    def moderate_reviews(self):
        query = "SELECT review_id, comment, rating, guest_id, room_id, review_date FROM Review"
        reviews = self.db.fetch_data(query)
        if not reviews:
            QMessageBox.information(self, "Info", "No reviews found.")
            return

        self.review_window = QWidget()
        self.review_window.setWindowTitle("Moderate Reviews")
        self.review_window.setGeometry(200, 200, 800, 400)

        layout = QVBoxLayout()
        table = QTableWidget()
        table.setRowCount(len(reviews))
        table.setColumnCount(6)
        table.setHorizontalHeaderLabels(["Review ID", "Comment", "Rating", "Guest ID", "Room ID", "Date"])
        for row, review in enumerate(reviews):
            for col, value in enumerate(review):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        layout.addWidget(table)
        self.review_window.setLayout(layout)
        self.review_window.show()

    def generate_reports(self):
        self.report_window = QWidget()
        self.report_window.setWindowTitle("Reports")
        self.report_window.setGeometry(200, 200, 800, 400)

        layout = QVBoxLayout()
        self.booking_report_button = QPushButton("Booking Report")
        self.style_button(self.booking_report_button, "#007bff")
        self.booking_report_button.clicked.connect(self.generate_booking_report)
        layout.addWidget(self.booking_report_button)

        self.payment_report_button = QPushButton("Payment Report")
        self.style_button(self.payment_report_button, "#28a745")
        self.payment_report_button.clicked.connect(self.generate_payment_report)
        layout.addWidget(self.payment_report_button)

        self.report_window.setLayout(layout)
        self.report_window.show()

    def generate_booking_report(self):
        query = "SELECT booking_id, room_id, guest_id, total_price, booking_status, check_in_date, check_out_date FROM Booking"
        bookings = self.db.fetch_data(query)
        if not bookings:
            QMessageBox.information(self, "Info", "No bookings found.")
            return

        self.booking_report_window = QWidget()
        self.booking_report_window.setWindowTitle("Booking Report")
        self.booking_report_window.setGeometry(200, 200, 800, 400)

        layout = QVBoxLayout()
        table = QTableWidget()
        table.setRowCount(len(bookings))
        table.setColumnCount(7)
        table.setHorizontalHeaderLabels(["ID", "Room", "Guest", "Price", "Status", "Check-In", "Check-Out"])
        for row, booking in enumerate(bookings):
            for col, value in enumerate(booking):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        layout.addWidget(table)
        self.booking_report_window.setLayout(layout)
        self.booking_report_window.show()

    def generate_payment_report(self):
        query = "SELECT payment_id, booking_id, guest_id, payment_date, payment_amount, payment_status FROM Payment WHERE payment_status = 'paid'"
        payments = self.db.fetch_data(query)
        if not payments:
            QMessageBox.information(self, "Info", "No payments found.")
            return

        self.payment_report_window = QWidget()
        self.payment_report_window.setWindowTitle("Payment Report")
        self.payment_report_window.setGeometry(200, 200, 800, 400)

        layout = QVBoxLayout()
        table = QTableWidget()
        table.setRowCount(len(payments))
        table.setColumnCount(6)
        table.setHorizontalHeaderLabels(["ID", "Booking", "Guest", "Date", "Amount", "Status"])
        for row, payment in enumerate(payments):
            for col, value in enumerate(payment):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        layout.addWidget(table)
        self.payment_report_window.setLayout(layout)
        self.payment_report_window.show()

if __name__ == "__main__":
    from PyQt5.QtWidgets import QApplication
    app = QApplication([])
    window = AdminDashboard()
    window.show()
    app.exec_()